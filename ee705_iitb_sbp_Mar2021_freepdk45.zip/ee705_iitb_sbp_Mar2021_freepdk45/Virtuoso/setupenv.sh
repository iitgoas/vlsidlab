source /vlsi/cad/cadence/IC617.bash 
