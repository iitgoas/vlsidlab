#!/bin/bash

strmin -library mylib -strmFile ../Encounter/adder4.gds -view layout  -layerMap ./streamIn.map
