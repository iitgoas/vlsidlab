#!/bin/bash 

# License settings to be done in ~/.bashrc or ~/.cshrc
# 8.1 Version ENCOUNTER.
#source /vlsi/cad/cadence/digitalbashrc
encounter -init place_and_route.tcl -log ./pnr.log

